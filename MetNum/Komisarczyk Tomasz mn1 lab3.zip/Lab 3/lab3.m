% x = linspace(0,6*pi,50);
% y1 = sin(x);
% y2 = cos(x);
% figure, plot(x,y1,'bd',x,y2,'g');
% title('funckje trygonometryczne w przedziale[0,6pi]','FontSize',14);
% legend('sin','cos');
% xlabel('x'); ylabel('y')

