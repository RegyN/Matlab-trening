function [blad] = blad_bezw( x, y )
% komentarz

blad = abs(x-y);
end

