function [ y ] = func( x )
% komentarz
    y = cos(x);
end

