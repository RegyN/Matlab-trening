function [ yreal ] = func( x )
% FUNC Funkcja obliczaj�ca warto�� sinusa
% x - wektor warto�ci argument�w funkcji sin(x)
% yreal - wektor warto�ci wyj�cia funkcji

yreal = sin(x);

end

